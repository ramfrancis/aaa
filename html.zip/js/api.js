var url = 'https://jsonplaceholder.typicode.com/albums/2/photos';

    fetch(url)
        .then(res=>res.json())
        .then(data =>{
            // var posts= 
            //document.getElementById("posts").innerHtml = data[0].title;
            console.log(data)


            var postTitle = document.createElement("p");
            var postImg = document.createElement("img");

            postTitle.innerHTML = data[0].title; //THIOS IS FOR THE NUMBER OF THE IMAGE
            postImg.src = data[0].url; // SAME SHIT
            document.getElementById("posts").appendChild(postTitle); 
            document.getElementById("posts").appendChild(postImg); 

    
            document.getElementById("posts").appendChild(postTitle); 
            document.getElementById("posts").appendChild(postImg); 

        })
        
        .catch(err=>{
            console.log(err);
        })