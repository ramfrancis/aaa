// const btn = document.querySelector('button')
// var disable = btn.disabled 
// var disable =true;

function userVal() {
    let pattern = /[a-zA-Z0-9]+g/;
    let userName = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var cpassword = document.getElementById('cpassword').value;
    let email = document.getElementById('email').value;
    let paramCheck,match = false;
    let passwordCheck = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/; //regex bs 
    let usernameCheck = /^\d/;


    console.log(userName);
    if (userName.length >= 3 && userName.match(usernameCheck) == null) {                                     //    if (userName >= 3 && pattern == true) {
        document.getElementById("cssUsername").style.color = "green";
        paramCheck = true;
    }else{
        document.getElementById("cssUsername").style.color = "red";
       error("USERNAME NOT CORRECT");
    }

    if(email.length != 0){
        document.getElementById("cssEmail").style.color = "green";
    }else{
        document.getElementById("cssEmail").style.color = "red";
    }

    if(password.length >=8 && password === cpassword ){
        match = true;
        document.getElementById("cssPassword").style.color = "green";
        document.getElementById("cssPassword").style.color = "green";
        document.getElementById("cssCPassword").style.color = "green";
        document.getElementById("cssCPassword").style.color = "green";

    }else{
        document.getElementById("cssPassword").style.color = "red";
        document.getElementById("cssPassword").style.color = "red";
        document.getElementById("cssCPassword").style.color = "red";
        document.getElementById("cssCPassword").style.color = "red";
        error("PASSWORDS DO NOT MATCH OR DO NOT HAVE 8 CHARACTERS!")

    }

    if (paramCheck == true && match == true ) {
        // disable =false;]
        submit()
        return true
    }else{
        return false;
    }
}

function submit() {
    alert("submmited"); 
    location.reload(); 

}
// "^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$" password